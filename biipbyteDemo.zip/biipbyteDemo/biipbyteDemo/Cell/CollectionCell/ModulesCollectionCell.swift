//
//  ModulesCollectionCell.swift
//  biipbyteDemo
//
//  Created by Anand Nanavaty on 22/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import UIKit

class ModulesCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var aImageView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    
}
