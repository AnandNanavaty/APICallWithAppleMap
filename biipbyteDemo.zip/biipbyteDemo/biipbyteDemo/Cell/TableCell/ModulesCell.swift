//
//  ModulesCell.swift
//  biipbyteDemo
//
//  Created by Anand Nanavaty on 22/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import UIKit

class ModulesCell: UITableViewCell {

    //MARK: Object initialization
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var aCollectionView: UICollectionView!
    var aModuleData : [[String:Any]] = [[:]]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.aCollectionView.dataSource = self
        self.aCollectionView.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//MARK: UICollectionView delegate, datasource and flow layout methods.

extension ModulesCell : UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.aModuleData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let aCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ModulesCollectionCell", for: indexPath) as! ModulesCollectionCell
        aCell.contentView.backgroundColor = .lightGray
        if aModuleData.count > 0 {
            let aDict = aModuleData[indexPath.row]
            aCell.contentView.layer.cornerRadius = 5.0
            if let aStrUrl = aDict["photo_cat"] as? String {
                aCell.aImageView.sd_setImage(with: URL.init(string: aStrUrl), completed: nil)
            }
            if let aName = aDict["name"] as? String {
                aCell.lblName.text = aName
            }            
        }
        return aCell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 150, height: 150)
    }
}
