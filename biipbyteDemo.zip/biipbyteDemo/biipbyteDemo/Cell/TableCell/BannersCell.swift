//
//  BannersCell.swift
//  biipbyteDemo
//
//  Created by Anand Nanavaty on 21/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import UIKit

class BannersCell: UITableViewCell {
    
    //MARK: Object initialization
    
    @IBOutlet weak var aCollectionView: UICollectionView!    
    @IBOutlet weak var lblTitle: UILabel!
    var aBannerData : [[String:Any]] = [[:]]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        aCollectionView.dataSource = self
        aCollectionView.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}

//MARK: UICollectionView delegate, datasource and flow layout methods.

extension BannersCell : UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.aBannerData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       let aCell = collectionView.dequeueReusableCell(withReuseIdentifier: "BannersCollectionCell", for: indexPath) as! BannersCollectionCell
        aCell.contentView.backgroundColor = .lightGray
        if aBannerData.count > 0 {
            let aDict = aBannerData[indexPath.row]
            aCell.contentView.layer.cornerRadius = 5.0
            if let aStrUrl = aDict["image"] as? String {
                aCell.aImageView.sd_setImage(with: URL.init(string: aStrUrl), completed: nil)
            }
        }
        return aCell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: self.aCollectionView.frame.width, height: self.aCollectionView.frame.height)
    }
}
