//
//  BrandsCell.swift
//  biipbyteDemo
//
//  Created by Anand Nanavaty on 22/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import UIKit

class BrandsCell: UITableViewCell {

    //MARK: Object initialization
    
    @IBOutlet weak var aCollectionView: UICollectionView!
    @IBOutlet weak var lblTitle: UILabel!
    var aImageData : [[String:Any]] = [[:]]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.aCollectionView.dataSource = self
        self.aCollectionView.delegate = self
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
//MARK: UICollectionView delegate, datasource and flow layout methods.

extension BrandsCell : UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.aImageData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let aCell = collectionView.dequeueReusableCell(withReuseIdentifier: "BrandsCollectionCell", for: indexPath) as! BrandsCollectionCell
        aCell.contentView.backgroundColor = .lightGray
        if aImageData.count > 0 {
            let aDict = aImageData[indexPath.row]
            aCell.contentView.layer.cornerRadius = 5.0
            if let aStrUrl = aDict["image"] as? String {
                aCell.aImageView.sd_setImage(with: URL.init(string: aStrUrl), completed: nil)
            }
            if let aStrUrlPhotoAndroid = aDict["photo_android5"] as? String {
                aCell.aImageView.sd_setImage(with: URL.init(string: aStrUrlPhotoAndroid), completed: nil)
            }

        }
        return aCell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 125, height: 125)
    }
}
