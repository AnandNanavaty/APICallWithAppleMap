//
//  AppleMapVC.swift
//  biipbyteDemo
//
//  Created by Anand Nanavaty on 02/06/19.
//  Copyright © 2019 AP. All rights reserved.
//

import UIKit
import MapKit

class AppleMapVC: UIViewController {

    let locationManager = CLLocationManager()
    let newPin = MKPointAnnotation()

    @IBOutlet weak var aMapView: MKMapView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        aMapView.delegate = self
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        locationManager.startUpdatingLocation()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension AppleMapVC : MKMapViewDelegate {
    
}

extension AppleMapVC : CLLocationManagerDelegate {
 
    private func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.requestLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        aMapView.removeAnnotation(newPin)
        if locations.first != nil {
            print("location:: (location)")
            let location = locations.last! as CLLocation
            //23.0225 72.5714
            let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))
            
            aMapView.setRegion(region, animated: true)
            
            newPin.coordinate = location.coordinate
            aMapView.addAnnotation(newPin)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("error :- \(error.localizedDescription)")
    }
}
