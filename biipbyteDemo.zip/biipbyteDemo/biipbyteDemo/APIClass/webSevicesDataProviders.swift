//
//  webSevicesDataProviders.swift
//  biipbyteDemo
//
//  Created by AP on 21/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

class webSevicesDataProviders: NSObject
{
    class var webServiceSharedInstance: webSevicesDataProviders
    {
        struct Static
        {
            static let instance = webSevicesDataProviders()
        }
        return Static.instance
    }
    func getData(url:String, reqMethod : Alamofire.HTTPMethod ,param : [String : Any],
                 success : @escaping (_ ResponseDict:Any?, _ status:Bool)->Void,
                 failure: @escaping (_ status:Bool, _ strErrorCode: String)->Void) {
        
        print(url)
        print(param)
        
        let AlFireReq : DataRequest = self.getRequest(apiUrl: url, reqMethod: reqMethod, param: param)
        
        AlFireReq.validate(statusCode: 200...3850).responseJSON(completionHandler: { (response) in
            
            if !CommonFunctions.isConnectedToInternet() {
                CommonFunctions.showMessage(message: "No Internet connection, Please try again.", withTitle: "BiipByte")
                return
            }
            if response.response?.statusCode == nil {
                
                failure(false, "")
            }
            
            if response.response?.statusCode == 511 {
                
                
            }
            else if response.response?.statusCode == 424 {
                do
                {
                    let jsonObj = try JSONSerialization.jsonObject(with: response.data!, options: [.allowFragments]) as! NSDictionary
                    print(jsonObj as Any)
                    
                    let result = self.hendleIfAnyError(jsonObj)
                    
                    success(result, false)
                    
                }
                catch{
                    
                }
                
            }
            else if response.response?.statusCode == 401 {
                
            } else {
                switch (response.result) {
                case .success:
                    do
                    {
                        let jsonObj = try JSONSerialization.jsonObject(with: response.data!, options: [.allowFragments]) as! NSDictionary
                        print(jsonObj as Any)
                        
                        let result = self.hendleIfAnyError(jsonObj)
                        
                        success(result, true)
                    }
                    catch{
                        
                    }
                    break
                case .failure( _):
                    failure(false, (response.result.error?.localizedDescription)!)
                    break
                }
            }
        })
    }
    
    func hendleIfAnyError(_ response : NSDictionary) -> Data{
        
        let Dic : NSMutableDictionary = (response.mutableCopy() as! NSMutableDictionary)
        if let errorArr = response.value(forKey: "error") as? NSDictionary{
            for errorStr in errorArr.allValues{
                Dic.setObject(errorStr, forKey: "error" as NSCopying)
            }
        }
        
        if let errorArr = response.value(forKey: "error") as? NSArray{
            // for errorStr in errorArr {
            Dic.setObject(errorArr, forKey: "error" as NSCopying)
            // }
        }
        
        do
        {
            let EditedData = try JSONSerialization.data(withJSONObject: Dic, options: [])
            return EditedData
        }
        catch{
            
        }
        return Data()
    }
    func getRequest(apiUrl: String, reqMethod:HTTPMethod, param: [String : Any]) -> DataRequest {
        let url: URL = CommonFunctions.getEncodedURL(strUrl: apiUrl)
        var AlFireReq : DataRequest!
        
        var headers = Alamofire.SessionManager.defaultHTTPHeaders
        headers["Content-Type"] = "application/json"
        
        if reqMethod == .get {
            AlFireReq =  Alamofire.request(url, method: reqMethod, parameters: param, encoding: URLEncoding.default, headers: headers)
        } else {
            AlFireReq =  Alamofire.request(url, method: reqMethod, parameters: param, encoding: JSONEncoding.default, headers: headers)
        }
        return AlFireReq
    }
}
