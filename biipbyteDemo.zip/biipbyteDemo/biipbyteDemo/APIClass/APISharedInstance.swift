//
//  APISharedInstance.swift
//  biipbyteDemo
//
//  Created by AP on 21/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import Foundation
class APISharedInstance  {
    class var sharedInstance: APISharedInstance
    {
        struct Static
        {
            static let instance = APISharedInstance()
        }
        return Static.instance
    }
    func getImages(_ api : String, _ resultBlock : @escaping ResultBlock){
        let aDict = ["api_key_data":"tz6n5M+lnJVw007muIr7UXATrR4quD9V4Z+upTXcDXWzD7LE1eZaHdcyBe/Z3TjChzPdgS5dKvVIQm6gq6HVuw==" , "user_type":"buyer"] as [String:Any]

        SHA_WS.getData(url: api, reqMethod: .post, param: aDict, success: { (responseData, status) in
            //print("\(responseData)")
            do{
                let jsonObj = try JSONSerialization.jsonObject(with: responseData as! Data, options: [.allowFragments]) as! NSDictionary
                if let aData = jsonObj as? [String:Any]{
                   if let data = aData["response"] as? [String:Any] {
                        if let aStatus = data["status"] as? String {
                            if aStatus == "1"{
                                if let aSubData = data["data"] as? [String:Any]{
                                    resultBlock(aSubData)
                                }
                            }else {
                              CommonFunctions.showMessage(message: data["message"] as? String ?? Went_Wrong , withTitle: Title)
                            }
                        }else {
                            CommonFunctions.showMessage(message: data["message"] as? String ?? Went_Wrong , withTitle: Title)
                        }
                    }
                }
            } catch{
                resultBlock(nil)
            }
        }) { (error, str) in
            
        }
    }
}
