//
//  Constants.swift
//  biipbyteDemo
//
//  Created by AP on 21/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import Foundation

let APPDEL              = UIApplication.shared.delegate as! AppDelegate
typealias ResultBlock   = (_ result: Any?) -> Void
let SHA_API             = APISharedInstance.sharedInstance
let SHA_WS              = webSevicesDataProviders.webServiceSharedInstance
let baseURL             = "http://175.41.166.125/testservice/index.php/category/home_buyer"
let Title               = "BiipByte"
let Went_Wrong          = "Something went wrong, Please try again."
