//
//  LoaderView.swift
//  biipbyteDemo
//
//  Created by AP on 21/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import UIKit
extension UIViewController {
    
    func showHUD(progressLabel:String){
        DispatchQueue.main.async{
            let progressHUD = MBProgressHUD.showAdded(to: self.view, animated: true)
            progressHUD?.labelText = progressLabel
        }
    }
    
    func dismissHUD(isAnimated:Bool) {
        DispatchQueue.main.async{
            MBProgressHUD.hide(for: self.view, animated: isAnimated)
        }
    }
}
