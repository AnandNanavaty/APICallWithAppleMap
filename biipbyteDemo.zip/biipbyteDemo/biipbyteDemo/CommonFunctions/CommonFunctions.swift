//
//  CommonFunctions.swift
//  biipbyteDemo
//
//  Created by AP on 21/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import UIKit
import Foundation

class CommonFunctions : NSObject {
    
    //MARK: Internet Connection is available or not.
    class func isConnectedToInternet() ->Bool {
        return NetworkReachabilityManager()!.isReachable
        
    }
    
    //MARK: Encoded URL
    class func getEncodedURL(strUrl: String) -> URL{
        if strUrl.contains("%20") {
            return URL(string: strUrl as String)!
        } else {
            let encodedString : String = strUrl.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)!
            return URL(string: encodedString as String)!
        }
    }
    
    //MARK: Display Alert View
    class func showMessage(message: String, withTitle: String){
        let alert: UIAlertController = UIAlertController(title: withTitle, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        
        APPDEL.window?.makeKeyAndVisible()
        APPDEL.window?.rootViewController?.present(alert, animated: true, completion: nil)
        
    }
}

