//
//  ViewController.swift
//  biipbyteDemo
//
//  Created by AP on 21/05/19.
//  Copyright © 2019 AP. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    //MARK: Object initialization
    
    var aResponseData : [String:Any] = [:]
    @IBOutlet weak var tblView: UITableView!
    
    //MARK: View Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.showHUD(progressLabel: "Please wait...")
        SHA_API.getImages(baseURL) { (aResponse) in
            if let aData = aResponse as? [String:Any]{
                self.aResponseData = aData
                if let aBanners = self.aResponseData["banners"] as? [[String:Any]]{
                    print(aBanners[0]["id"]!)
                    print(aBanners[0]["image"]!)
                    print(aBanners[0]["name"]!)
                    let managedContext = APPDEL.persistentContainer.viewContext
                    let userEntity = NSEntityDescription.entity(forEntityName: "BannerTable", in: managedContext)
                    let user = NSManagedObject(entity: userEntity!, insertInto: managedContext)
                    user.setValue(aBanners[0]["id"]!, forKey: "id")
                    user.setValue(aBanners[0]["name"]!, forKey: "name")
                    user.setValue(aBanners[0]["image"]!, forKey: "image")
                    
                    do {
                        try managedContext.save()
                    }catch let error as NSError {
                        print(error.localizedDescription)
                    }
                    let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "BannerTable")
                    do {
                        let people = try managedContext.fetch(fetchRequest)
                        print(people.count)
                        for data in people {
                            print(data.value(forKey: "id") as! String)
                            print(data.value(forKey: "name") as! String)
                            print(data.value(forKey: "image") as! String)
                        }
                    }catch let error as NSError {
                        print(error.localizedDescription)
                    }
                }
                self.tblView.reloadData()
            }
            self.dismissHUD(isAnimated: true)
        }
    }
}

//MARK: UITableView delegate and datasource method

extension ViewController : UITableViewDataSource , UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 8
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }else if section == 1 {
            return 1
        }else if section == 2 {
            return 1
        }else if section == 3 {
            return 1
        }else if section == 4 {
            return 1
        }else if section == 5 {
            return 1
        }else if section == 6 {
            return 1
        }else if section == 7 {
            return 1
        }else {
            return 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            //Display banners
            let aCell = tableView.dequeueReusableCell(withIdentifier: "BannersCell") as! BannersCell
            if let aBanners = self.aResponseData["banners"] as? [[String:Any]]{
                aCell.lblTitle.text = "Home"
                aCell.aBannerData = aBanners
                aCell.aCollectionView.reloadData()
            }
            return aCell

        }else if indexPath.section == 1 {
            //Display brands
            let aCell = tableView.dequeueReusableCell(withIdentifier: "BrandsCell") as! BrandsCell
            if let aBrands = self.aResponseData["brands"] as? [[String:Any]]{
                aCell.aImageData = aBrands
                aCell.lblTitle.text = "Brands"
                aCell.aCollectionView.reloadData()
            }
            return aCell
        }else if indexPath.section == 2 {
            //Display Featured Products
            let aCell = tableView.dequeueReusableCell(withIdentifier: "BrandsCell") as! BrandsCell
            if let aFeaturedProducts = self.aResponseData["featured_products"] as? [[String:Any]]{
                aCell.aImageData = aFeaturedProducts
                aCell.lblTitle.text = "Featured Products"
                aCell.aCollectionView.reloadData()
            }
            return aCell
        }else if indexPath.section == 3 {
            //Display Popular Products
            let aCell = tableView.dequeueReusableCell(withIdentifier: "BrandsCell") as! BrandsCell
            if let aPopular = self.aResponseData["popular"] as? [[String:Any]]{
                aCell.aImageData = aPopular
                aCell.lblTitle.text = "Popular"
                aCell.aCollectionView.reloadData()
            }
            return aCell
        }else if indexPath.section == 4 {
            //Display Featured Deals
            let aCell = tableView.dequeueReusableCell(withIdentifier: "BannersCell") as! BannersCell
            if let aFeaturedDeals = self.aResponseData["featured_deals"] as? [[String:Any]]{
                aCell.lblTitle.text = "Featured Deals"
                aCell.aBannerData = aFeaturedDeals
                aCell.aCollectionView.reloadData()
            }
            return aCell
        }else if indexPath.section == 5 {
            let aCell = tableView.dequeueReusableCell(withIdentifier: "ModulesCell") as! ModulesCell
            if let aModules = self.aResponseData["modules"] as? [[String:Any]]{
                //Women's
                let filteredItems = aModules.filter { $0["id"] as! String == "3" }
                if let aCategories = filteredItems[0]["categories"] as? [[String:Any]]{
                    print(aCategories.count)
                    aCell.lblTitle.text = "Women's"
                    aCell.aModuleData = aCategories
                    aCell.aCollectionView.reloadData()
                }
            }
            return aCell
        }else if indexPath.section == 6 {
            let aCell = tableView.dequeueReusableCell(withIdentifier: "ModulesCell") as! ModulesCell
            if let aModules = self.aResponseData["modules"] as? [[String:Any]]{
                //Men's
                let filteredItems = aModules.filter { $0["id"] as! String == "2" }
                if let aCategories = filteredItems[0]["categories"] as? [[String:Any]]{
                    print(aCategories.count)
                    aCell.lblTitle.text = "Men's"
                    aCell.aModuleData = aCategories
                    aCell.aCollectionView.reloadData()
                }
            }
            return aCell
        }else {
            let aCell = tableView.dequeueReusableCell(withIdentifier: "ModulesCell") as! ModulesCell
            if let aModules = self.aResponseData["modules"] as? [[String:Any]]{
                //Everything Else
                let filteredItems = aModules.filter { $0["id"] as! String == "1" }
                if let aCategories = filteredItems[0]["categories"] as? [[String:Any]]{
                    print(aCategories.count)
                    aCell.lblTitle.text = "Everything Else"
                    aCell.aModuleData = aCategories
                    aCell.aCollectionView.reloadData()
                }
            }
            return aCell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let objAppleMap = self.storyboard?.instantiateViewController(withIdentifier: "AppleMapVC") as! AppleMapVC
        self.navigationController?.pushViewController(objAppleMap, animated: true)
    }
}
